import fs from 'node:fs/promises';
import path from 'node:path';
import lighthouse from './node_modules/lighthouse/core/index.js';
import * as chromeLauncher from './node_modules/chrome-launcher/dist/index.js';
const phase=process.argv[2]||'before';
const base=process.argv[3]||'https://maskarad-teatr.ru';
const rounds=Number(process.argv[4]||3);
const root=path.resolve('/private/tmp/maskarad-speed-086',phase);
await fs.mkdir(root,{recursive:true});
const routes=[['home','/'],['catalogue','/prazdniki'],['corporate','/prazdniki/korporativnyy-novogodniy-prazdnik'],['article','/stati/igrovoy-scenariy-dlya-detskogo-prazdnika']];
const rows=[];
const chrome=await chromeLauncher.launch({chromeFlags:['--headless=new','--disable-gpu','--no-first-run']});
try {
 for(let round=1;round<=rounds;round++) for(const [name,route] of routes) {
  const result=await lighthouse(base+route,{port:chrome.port,output:'json',onlyCategories:['performance'],logLevel:'error'});
  if(result.lhr.runtimeError) throw Error(JSON.stringify(result.lhr.runtimeError));
  const {lhr}=result;
  await fs.writeFile(path.join(root,`${name}-${round}.json`),JSON.stringify(lhr));
  if(round===1) {
   const trace=result.artifacts.Trace||result.artifacts.traces;
   if(trace) await fs.writeFile(path.join(root,`${name}-trace.json`),JSON.stringify(trace));
  }
  const value=id=>lhr.audits[id]?.numericValue;
  const row={phase,name,round,url:lhr.finalDisplayedUrl,version:lhr.lighthouseVersion,fetchTime:lhr.fetchTime,score:100*lhr.categories.performance.score,LCP:value('largest-contentful-paint'),FCP:value('first-contentful-paint'),CLS:value('cumulative-layout-shift'),TBT:value('total-blocking-time'),speedIndex:value('speed-index'),bytes:value('total-byte-weight'),warnings:lhr.runWarnings};
  rows.push(row);
  await fs.writeFile(path.join(root,'summary.json'),JSON.stringify(rows,null,2));
  console.log(JSON.stringify(row));
 }
} finally {await chrome.kill();}
