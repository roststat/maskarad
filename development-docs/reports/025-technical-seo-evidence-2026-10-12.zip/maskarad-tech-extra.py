exec(open('/private/tmp/maskarad-tech-audit.py').read().split("sitemap=fetch(")[0])
r=json.load(open(OUT+'/result.json'));ps=r['pages']
assets=set(a for p in ps for a in p['assets']);assets.update(p['meta'].get('og:image') for p in ps);assets.discard(None)
assets.update(i['src'] for p in ps[:2] for i in p['images'] if i.get('src'))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:res=list(pool.map(fetch,[urllib.parse.urljoin(BASE,a) for a in assets]))
json.dump(res,open(OUT+'/assets.json','w'),ensure_ascii=False,indent=2)
print('ASSET COUNT',len(res),'BAD',[(x['url'],x['status']) for x in res if x['status']!=200])
print('TOP',[(x['url'],x['bytes'],x['transfer'],x['headers'].get('cache-control'),x['headers'].get('content-encoding')) for x in sorted(res,key=lambda x:x['transfer'] or 0,reverse=True)[:10]])
errors=[]
for p in ps:
 norm=lambda t:' '.join(t.split())
 for s in p['jsonld']:
  if s.get('parseError'):errors.append((p['url'],'parse'))
  if s.get('@type')=='FAQPage':
   qs=s.get('mainEntity',[])
   if len(qs)!=5:errors.append((p['url'],'FAQ count',len(qs)))
   for q in qs:
    if norm(q.get('name','')) not in norm(p['text']) or norm(q.get('acceptedAnswer',{}).get('text','')) not in norm(p['text']):errors.append((p['url'],'FAQ parity',q.get('name')))
  if s.get('@type')=='Service':
   target=s.get('potentialAction',{}).get('target','')
   if isinstance(target,str) and '#' in target and target.split('#')[1] not in p['ids']:errors.append((p['url'],'action fragment',target))
print('SCHEMA ERRORS',errors)
print('EXTRAS META',[(p['url'],p.get('meta',{}).get('robots'),p['headers'].get('link')) for p in r['extras'] if p['status']==200])
print('TTFB',min(p['ttfb'] for p in ps),sorted(p['ttfb'] for p in ps)[61],max(p['ttfb'] for p in ps))
json.dump(errors,open(OUT+'/schema-errors.json','w'),ensure_ascii=False)
