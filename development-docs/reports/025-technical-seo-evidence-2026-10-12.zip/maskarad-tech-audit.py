import subprocess,json,hashlib,concurrent.futures,collections,os,urllib.parse,xml.etree.ElementTree as ET
from html.parser import HTMLParser
BASE='https://maskarad-teatr.ru'
OUT='/private/tmp/maskarad-tech-audit'
os.makedirs(OUT,exist_ok=True)
class Page(HTMLParser):
 def __init__(self):
  super().__init__(convert_charrefs=True);self.meta={};self.canonical=[];self.links=[];self.ids=[];self.images=[];self.assets=[];self.jsonld=[];self.title='';self.h1=[];self.text=[];self.capture=None;self.buf='';self.script=False
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='meta':self.meta[d.get('name',d.get('property',''))]=d.get('content','')
  if t=='link' and d.get('rel')=='canonical':self.canonical.append(d.get('href'))
  if t=='link' and d.get('rel')=='stylesheet':self.assets.append(d.get('href'))
  if t=='a' and d.get('href'):self.links.append(d['href'])
  if t=='img':self.images.append(d)
  if t=='script':
   self.script=True
   if d.get('src'):self.assets.append(d['src'])
   if d.get('type')=='application/ld+json':self.capture='ld';self.buf=''
  if t in ('title','h1'):self.capture=t;self.buf=''
 def handle_data(self,s):
  if self.capture:self.buf+=s
  if not self.script:self.text.append(s)
 def handle_endtag(self,t):
  if t=='script':
   if self.capture=='ld':
    try:
     v=json.loads(self.buf);self.jsonld.extend(v if isinstance(v,list) else [v])
    except: self.jsonld.append({'parseError':True})
    self.capture=None
   self.script=False
  if t==self.capture:
   if t=='title':self.title=self.buf
   if t=='h1':self.h1.append(self.buf)
   self.capture=None
def fetch(url):
 key=hashlib.sha256(url.encode()).hexdigest()[:16];path=f'{OUT}/{key}'
 p=subprocess.run(['curl','-sS','--compressed','--max-time','20','-D',path+'.headers','-o',path+'.body','-w','%{json}',url],capture_output=True,text=True)
 try:m=json.loads(p.stdout)
 except:m={}
 body=open(path+'.body','rb').read() if os.path.exists(path+'.body') else b''
 headers=open(path+'.headers').read() if os.path.exists(path+'.headers') else ''
 h={}
 for line in headers.splitlines():
  if ':' in line:
   k,v=line.split(':',1);h[k.lower()]=v.strip()
 r={'url':url,'status':m.get('http_code'),'ttfb':m.get('time_starttransfer'),'total':m.get('time_total'),'transfer':m.get('size_download'),'bytes':len(body),'headers':h,'body_file':path+'.body','error':p.stderr}
 if 'text/html' in h.get('content-type',''):
  q=Page();q.feed(body.decode('utf8','replace'));r.update({k:getattr(q,k) for k in ['meta','canonical','links','ids','images','assets','jsonld','title','h1']});r['text']=' '.join(q.text)
 return r
sitemap=fetch(BASE+'/sitemap.xml')
root=ET.parse(sitemap['body_file']);urls=[x.text for x in root.findall('.//{*}loc')];urls=list(dict.fromkeys(urls))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:pages=list(pool.map(fetch,urls))
by_path={urllib.parse.urlsplit(p['url']).path or '/':p for p in pages};extra=set();anchors=[]
for p in pages:
 for href in p.get('links',[]):
  u=urllib.parse.urlsplit(urllib.parse.urljoin(p['url'],href))
  if u.netloc!='maskarad-teatr.ru':continue
  path=u.path or '/'
  if path not in by_path and not path.startswith(('/api/','/admin/','/_next/')) and not os.path.splitext(path)[1]:extra.add(BASE+path)
  if u.fragment:anchors.append((p['url'],path,urllib.parse.unquote(u.fragment)))
variants=['http://maskarad-teatr.ru/','http://www.maskarad-teatr.ru/','https://www.maskarad-teatr.ru/','https://www.maskarad-teatr.ru/spektakli',BASE+'/spektakli/',BASE+'/?utm_source=audit',BASE+'/__seo-audit-not-found-20261012',BASE+'/spektakli/__seo-audit-not-found-20261012',BASE+'/detskii-prazdnik/__seo-audit-not-found-20261012',BASE+'/markdown/spektakli/zolushka',BASE+'/robots.txt']
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:extras=list(pool.map(fetch,sorted(extra|set(variants))))
for p in extras:
 if p['status']==200 and urllib.parse.urlsplit(p['url']).netloc=='maskarad-teatr.ru':by_path.setdefault(urllib.parse.urlsplit(p['url']).path or '/',p)
brokenanchors=[{'from':a,'target':b+'#'+c} for a,b,c in anchors if b in by_path and c not in by_path[b].get('ids',[])]
groups={}
for name,fn in [('title',lambda p:p.get('title')),('description',lambda p:p.get('meta',{}).get('description'))]:
 g=collections.defaultdict(list)
 for p in pages:g[fn(p)].append(p['url'])
 groups[name]={k:v for k,v in g.items() if len(v)>1 or not k}
seen={'/'};queue=['/']
while queue:
 p=by_path[queue.pop()]
 for l in p.get('links',[]):
  u=urllib.parse.urlsplit(urllib.parse.urljoin(p['url'],l));path=u.path or '/'
  if u.netloc=='maskarad-teatr.ru' and path in by_path and path not in seen:seen.add(path);queue.append(path)
summary={'sitemap_count':len(urls),'bad_status':[p['url'] for p in pages if p['status']!=200],'canonical_errors':[p['url'] for p in pages if p.get('canonical')!=[p['url'].rstrip('/') if p['url'].endswith('/') else p['url']] and p.get('canonical')!=[p['url']]],'h1_errors':[p['url'] for p in pages if len(p.get('h1',[]))!=1],'noindex':[p['url'] for p in pages if 'noindex' in p.get('meta',{}).get('robots','')],'duplicates':groups,'unreachable':[p for p in by_path if p not in seen and p in {urllib.parse.urlsplit(u).path or '/' for u in urls}],'broken_anchors':brokenanchors,'og_url_mismatch':[p['url'] for p in pages if p.get('meta',{}).get('og:url','').rstrip('/')!=p['url'].rstrip('/')],'missing_alt':sum('alt' not in i for p in pages for i in p.get('images',[]))}
result={'summary':summary,'sitemap':sitemap,'pages':pages,'extras':extras}
json.dump(result,open(OUT+'/result.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(summary,ensure_ascii=False,indent=2));print('EXTRAS',[(p['url'],p['status'],p['headers'].get('location')) for p in extras])
